function [Mred_tra,Mred_tes]=PCA(comp,data_tra,data_tes,option)

switch option
    case 1 
        data=data_tra;
    case 2
        data=[data_tra data_tes];   
end

        [N,~]=size(data);
        u=mean(data);
        data=data-repmat(u,N,1);
        
        [coeff score latent] = pca(data);
        V = coeff(:, 1:comp);
        
        [N,~]=size(data_tra);
        data_tra=data_tra-repmat(u,N,1);
        Mred_tra=data_tra*V;
        
        [N,~]=size(data_tes);
        data_tes=data_tes-repmat(u,N,1);
        Mred_tes=data_tes*V;
end

