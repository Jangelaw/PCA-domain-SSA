function [data_tra,data_tes,label_tra,label_tes]=SelectSAMPLE(data,label,option)

switch option
    case 1
    % Distribute the ground truth into 10 groups
    split_number = 10;
    y = label;
    ymin=min(y);
    ymax=max(y);
    x=linspace(ymin,ymax,split_number);
    yy=hist(y,x);

    class = [];
    for i = 1:split_number
        m = yy(i);
        if m ~= 0
            for j = 1:m
                f(j,1) = i;
            end
        else
            f = [];
        end
        class = [class;f];
        clear f
    end

    p = 0.75;  %train p;   predict 1-p

    NN=zeros(size(yy,2),max(yy));
    for i=1:size(yy,2)
        nn=randperm(yy(i));
        NN(i,nn>ceil(yy(i)*p))=2;   % 2 for testing
        NN(i,nn<=ceil(yy(i)*p))=1;  % 1 for training
        clear nn
    end
    clear i j m f y

    % Construct training set and training ground truth
    label_tra = []; label_tes = [];
    data_tra = []; data_tes = [];
    nn=zeros(size(yy,2),max(yy));
    for i = 1:length(label)
        if class(i) ~= 0
            switch class(i)
                case 1
                    nn(1) = nn(1) + 1;
                    if NN(1,nn(1)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(1,nn(1)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
                case 2
                    nn(2) = nn(2) + 1;
                    if NN(2,nn(2)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(2,nn(2)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
                case 3
                    nn(3) = nn(3) + 1;
                    if NN(3,nn(3)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(3,nn(3)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
                case 4
                    nn(4) = nn(4) + 1;
                    if NN(4,nn(4)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(4,nn(4)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
                case 5
                    nn(5) = nn(5) + 1;
                    if NN(5,nn(5)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(5,nn(5)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
                case 6
                    nn(6) = nn(6) + 1;
                    if NN(6,nn(6)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(6,nn(6)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
                case 7
                    nn(7) = nn(7) + 1;
                    if NN(7,nn(7)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(7,nn(7)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
                case 8
                    nn(8) = nn(8) + 1;
                    if NN(8,nn(8)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(8,nn(8)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
                case 9
                    nn(9) = nn(9) + 1;
                    if NN(9,nn(9)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(9,nn(9)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
                case 10
                    nn(10) = nn(106) + 1;
                    if NN(10,nn(10)) == 1
                        label_tra = [label_tra; label(i)];
                        data_tra = [data_tra; data(i,:)];
                    else if NN(10,nn(10)) == 2
                            label_tes = [label_tes; label(i)];
                            data_tes = [data_tes; data(i,:)];
                        end
                    end
            end
        end
    end
    
    case 2
        
        label_tra = []; label_tes = [];
        data_tra = []; data_tes = [];
        
        for i = 1:length(label)
            if mod(i,4) == 0
                label_tes = [label_tes; label(i)];
                data_tes = [data_tes; data(i,:)];
            else
                label_tra = [label_tra; label(i)];
                data_tra = [data_tra; data(i,:)];
            end
        end
        
    case 3
        label_tra = []; label_tes = [];
        data_tra = []; data_tes = [];
        
        leng = round(length(label)/4);
        
        for i = 1:leng
            m = 4*i-2;
            label_tes = [label_tes; label(m)];
            data_tes = [data_tes; data(m,:)];
        end

        row = [];
        for j = 1:length(label_tes)
            r = data_tes(j,:);
            n = find_row(data,r);
            row = [row;n];
        end

        temp = 1:1:length(label);
        temp = temp';
        
        coor = setdiff(temp,row,'rows');
        for k = 1:length(coor)
            label_tra = [label_tra;label(coor(k))];
            data_tra = [data_tra;data(coor(k),:)];
        end
        
    case 4
        label_tra = []; label_tes = [];
        data_tra = []; data_tes = [];
        
        leng = ceil(length(label)/4);
        
        for i = 1:leng
            m = 4*i-3;
            label_tes = [label_tes; label(m)];
            data_tes = [data_tes; data(m,:)];
        end

        row = [];
        for j = 1:length(label_tes)
            r = data_tes(j,:);
            n = find_row(data,r);
            row = [row;n];
        end

        temp = 1:1:length(label);
        temp = temp';
        
        coor = setdiff(temp,row,'rows');
        for k = 1:length(coor)
            label_tra = [label_tra;label(coor(k))];
            data_tra = [data_tra;data(coor(k),:)];
        end
end
end
            
