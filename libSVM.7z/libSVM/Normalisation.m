function [Mnorm_tra,Mnorm_tes]=Normalisation(Mred_tra,Mred_tes,option)

    switch option
        case 1 
            % normalisation feature by feature 0mean1var
            [feat,samp]=size(Mred_tra);
            for k=1:feat
                mean_val(k)=mean(Mred_tra(k,:));
                varian_val(k)=var(Mred_tra(k,:));
                Mnorm_tra(k,:)=Mred_tra(k,:)-mean_val(k);
                Mnorm_tra(k,:)=Mnorm_tra(k,:) ./sqrt(varian_val(k)); 
                Mnorm_tes(k,:)=Mred_tes(k,:)-mean_val(k);
                Mnorm_tes(k,:)=Mnorm_tes(k,:) ./sqrt(varian_val(k));  
            end
            
        case 2
            % normalisation feature by feature [-1,1]
            [feat,samp]=size(Mred_tra);
            for k=1:feat
                min_val(k)=min(Mred_tra(k,:));
                max_val(k)=max(Mred_tra(k,:));
                Mnorm_tra(k,:)=Mred_tra(k,:)-min_val(k);
                Mnorm_tra(k,:)=Mnorm_tra(k,:) ./(max_val(k)-min_val(k));
                Mnorm_tra(k,:)=2*(Mnorm_tra(k,:)-0.5);
                Mnorm_tes(k,:)=Mred_tes(k,:)-min_val(k);
                Mnorm_tes(k,:)=Mnorm_tes(k,:) ./(max_val(k)-min_val(k)); 
                Mnorm_tes(k,:)=2*(Mnorm_tes(k,:)-0.5);
            end
            
        case 3
            % normalisation all together 0mean1var
            mean_val=mean(Mred_tra(:));
            varian_val=var(Mred_tra(:));
            Mnorm_tra=Mred_tra-mean_val;
            Mnorm_tra=Mnorm_tra ./sqrt(varian_val); 
            Mnorm_tes=Mred_tes-mean_val;
            Mnorm_tes=Mnorm_tes ./sqrt(varian_val); 
            
        case 4
            % normalisation all together [-1 1]
            maxVal=max(Mred_tra(:));
            minVal=min(Mred_tra(:));
            Mnorm_tra=Mred_tra-minVal;
            Mnorm_tra=Mnorm_tra./(maxVal-minVal);
            Mnorm_tra=2*(Mnorm_tra-0.5);
            Mnorm_tes=Mred_tes-minVal;
            Mnorm_tes=Mnorm_tes./(maxVal-minVal);
            Mnorm_tes=2*(Mnorm_tes-0.5); 
    end
end

